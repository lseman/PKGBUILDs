---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

**Have you checked the readme and man page for this feature?**
**Have you checked previous issues for this feature?**
